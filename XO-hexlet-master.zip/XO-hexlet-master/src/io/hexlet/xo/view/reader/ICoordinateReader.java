package io.hexlet.xo.view.reader;

public interface ICoordinateReader {
    int askCoordinate(final String coordinateName);
}
