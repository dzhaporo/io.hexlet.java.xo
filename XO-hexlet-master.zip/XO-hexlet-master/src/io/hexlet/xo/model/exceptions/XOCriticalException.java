package io.hexlet.xo.model.exceptions;

public class XOCriticalException extends RuntimeException {

    public XOCriticalException(final Throwable cause) {
        super(cause);
    }

}
