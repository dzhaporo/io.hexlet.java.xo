package io.hexlet.xo.model.exceptions;


public class InvalidPointException extends AbstractXOException {
}
