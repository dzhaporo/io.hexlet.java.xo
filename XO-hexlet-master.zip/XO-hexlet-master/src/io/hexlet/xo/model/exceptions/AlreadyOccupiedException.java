package io.hexlet.xo.model.exceptions;


public class AlreadyOccupiedException extends AbstractXOException {
}
