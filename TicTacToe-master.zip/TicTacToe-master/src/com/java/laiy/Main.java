
package com.java.laiy;

import com.java.laiy.view.*;

public class Main {

    public static void main(final String[] args) {
        ConsoleMenuView.showMenuWithResult();
    }

}