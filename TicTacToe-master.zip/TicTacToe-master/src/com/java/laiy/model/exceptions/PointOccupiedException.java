package com.java.laiy.model.exceptions;

public class PointOccupiedException extends AbstractTicTacException{
}
