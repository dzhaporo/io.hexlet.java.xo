package com.java.laiy.model.exceptions;

public class InvalidPointException extends AbstractTicTacException{

}
