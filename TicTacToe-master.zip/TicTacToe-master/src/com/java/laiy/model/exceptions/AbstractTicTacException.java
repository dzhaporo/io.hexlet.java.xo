package com.java.laiy.model.exceptions;

public abstract class AbstractTicTacException extends Exception {
}
