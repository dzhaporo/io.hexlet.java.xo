package com.java.laiy.model.exceptions;

public class InvalidBoardSizeException  extends AbstractTicTacException{
}
